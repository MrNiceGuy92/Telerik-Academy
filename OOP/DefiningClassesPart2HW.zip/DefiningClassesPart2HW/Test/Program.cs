﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Points;

namespace Test
{
    public class Test
    {
        static void Main()
        {
            Point3D firstPoint = new Point3D(2, 3, 4);
            Console.WriteLine(firstPoint.ToString());
        }
    }
}
